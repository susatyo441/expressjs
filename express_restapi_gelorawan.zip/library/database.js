module.exports = {
  multipleStatements: true,
  host: "localhost",
  user: "root",
  password: null,
  database: "gamelab",
};
